from langgraph.graph import StateGraph
from datetime import datetime
import json
import os

class StudentState(dict):
    pass

def load_tasks(state: StudentState):
    with open(os.path.join("data", "tasks.json"), "r") as f:
        state["tasks"] = json.load(f)
    return state

def analyze_priorities(state: StudentState):
    today = datetime.now()
    for t in state["tasks"]:
        deadline = datetime.strptime(t["deadline"], "%Y-%m-%d")
        days_left = (deadline - today).days
        if days_left <= 2:
            t["priority"] = "High"
        elif days_left <= 5:
            t["priority"] = "Medium"
        else:
            t["priority"] = "Low"
    state["tasks"] = sorted(state["tasks"], key=lambda x: x["priority"])
    return state

def generate_study_plan(state: StudentState):
    high = [t["name"] for t in state["tasks"] if t["priority"] == "High"]
    med = [t["name"] for t in state["tasks"] if t["priority"] == "Medium"]
    low = [t["name"] for t in state["tasks"] if t["priority"] == "Low"]

    suggestions = []
    if high:
        suggestions.append(f"Focus today on: {', '.join(high)} (High priority)")
    if med:
        suggestions.append(f"Plan for next 3 days: {', '.join(med)}")
    if low:
        suggestions.append(f"Keep in weekend slot: {', '.join(low)}")

    suggestions.append("Recommended: Study 7–9 PM daily and take 10-min breaks hourly.")
    state["study_plan"] = suggestions
    return state

def reflect_and_adjust(state: StudentState):
    print("\n📘 Reflection: Checking if tasks are on track...")
    completed = input("Enter completed tasks (comma separated): ").split(",")
    completed = [c.strip() for c in completed if c.strip()]
    state["tasks"] = [t for t in state["tasks"] if t["name"] not in completed]

    if not state["tasks"]:
        state["study_plan"] = ["✅ All tasks completed! Take a break!"]
        return state

    print("🔁 Re-analyzing remaining tasks...")
    return analyze_priorities(state)

def build_agent_graph():
    graph = StateGraph(StudentState)
    graph.add_node("load_tasks", load_tasks)
    graph.add_node("analyze_priorities", analyze_priorities)
    graph.add_node("generate_study_plan", generate_study_plan)
    graph.add_node("reflect_and_adjust", reflect_and_adjust)

    graph.add_edge("load_tasks", "analyze_priorities")
    graph.add_edge("analyze_priorities", "generate_study_plan")
    graph.add_conditional_edges(
        "generate_study_plan",
        lambda state: "reflect_and_adjust" if input("\nReflect? (y/n): ").lower() == "y" else None,
        {"reflect_and_adjust": "reflect_and_adjust"}
    )

    graph.set_entry_point("load_tasks")
    return graph.compile()

if __name__ == "__main__":
    graph = build_agent_graph()
    state = graph.invoke({})
    print("\n📅 Study Plan Generated:")
    for s in state["study_plan"]:
        print("-", s)
